// Any copyright is dedicated to the Public Domain.
// http://creativecommons.org/licenses/publicdomain/

load("ecma_5/Object/defineProperty-setup.js");
runNonTerminalPropertyPresentTestsFraction(2, 8);
