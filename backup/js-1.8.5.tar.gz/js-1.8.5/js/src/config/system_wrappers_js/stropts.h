#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <stropts.h>
#pragma GCC visibility pop
