#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <direct/utf8.h>
#pragma GCC visibility pop
