#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <direct/interface.h>
#pragma GCC visibility pop
