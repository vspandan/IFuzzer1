#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <atlcom.h>
#pragma GCC visibility pop
