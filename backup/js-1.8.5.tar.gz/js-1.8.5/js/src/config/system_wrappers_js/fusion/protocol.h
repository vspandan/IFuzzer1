#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <fusion/protocol.h>
#pragma GCC visibility pop
