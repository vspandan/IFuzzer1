#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <sys/param.h>
#pragma GCC visibility pop
