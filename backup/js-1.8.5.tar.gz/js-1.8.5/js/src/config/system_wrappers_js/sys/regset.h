#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <sys/regset.h>
#pragma GCC visibility pop
