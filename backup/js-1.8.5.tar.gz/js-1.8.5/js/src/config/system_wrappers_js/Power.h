#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <Power.h>
#pragma GCC visibility pop
