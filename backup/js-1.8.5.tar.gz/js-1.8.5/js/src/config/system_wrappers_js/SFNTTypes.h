#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <SFNTTypes.h>
#pragma GCC visibility pop
