#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <Memory.h>
#pragma GCC visibility pop
