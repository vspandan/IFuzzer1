#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <fnmatch.h>
#pragma GCC visibility pop
