#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <photon/PpProto.h>
#pragma GCC visibility pop
