#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <IOKit/IOKitLib.h>
#pragma GCC visibility pop
