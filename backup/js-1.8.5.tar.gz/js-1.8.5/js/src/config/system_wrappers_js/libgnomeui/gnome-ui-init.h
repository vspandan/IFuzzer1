#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <libgnomeui/gnome-ui-init.h>
#pragma GCC visibility pop
