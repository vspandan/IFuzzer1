(function() {
  for (e in [0, 0]) {
    if (/x/ < this) {}
  }
})()

/* Don't assert. */

