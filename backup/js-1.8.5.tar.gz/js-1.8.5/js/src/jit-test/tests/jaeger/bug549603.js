// |jit-test| error: ReferenceError
x ? o : [] && x

