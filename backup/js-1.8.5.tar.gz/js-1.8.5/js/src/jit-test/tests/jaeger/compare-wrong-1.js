function f(a) { return a; }
assertEq(print < f, false);
assertEq(print > f, true);

