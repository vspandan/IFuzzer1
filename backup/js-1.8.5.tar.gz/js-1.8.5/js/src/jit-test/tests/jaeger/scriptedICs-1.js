T = 12;

function arity2(q, w, r, t, y) {
    var Q1;
    var Q2;
    var Q3;
    var Q4;
    var Q5;
    var Q6;
    var Q7;
    var Q8;
    var Q9;
    T;
    return arguments;
}

function arity(q, w, r) {
    var Q1;
    var Q2;
    var Q3;
    var Q4;
    var Q5;
    var Q6;
    var Q7;
    var Q8;
    var Q9;
    T;
    return Q9;
}

for (var i = 0; i < 10; i++) {
    arity();
    if (i == 6)
        arity = arity2;
}

/* Don't assert - stubs::CompileFunction must correct |regs.sp| */


