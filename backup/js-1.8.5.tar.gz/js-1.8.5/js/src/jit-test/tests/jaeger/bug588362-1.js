for (a = 0; a < HOTLOOP + 5; a++) {
    (function e() {
        yield eval()
    }())
}

/* Don't assert. */

