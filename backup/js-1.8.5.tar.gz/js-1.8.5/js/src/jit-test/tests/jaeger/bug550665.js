(function () {
  var a;
  eval("for(w in ((function(x,y){b:0})())) ;");
})();

this.__defineSetter__("l", function() { gc() });
this.watch("l", function(x) { yield #1={} });
l = true;
