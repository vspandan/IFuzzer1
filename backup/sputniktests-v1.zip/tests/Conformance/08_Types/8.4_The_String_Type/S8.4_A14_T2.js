// Copyright 2009 the Sputnik authors.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/**
* @name: S8.4_A14_T2;
* @section: 8.4;
* @assertion: When appears not closed double-quote program failes;
* @description: Try to create variable using 3 double-quote;
* @negative;
*/

var str = """;
