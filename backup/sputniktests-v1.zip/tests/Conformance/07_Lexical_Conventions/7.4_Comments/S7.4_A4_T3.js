// Copyright 2009 the Sputnik authors.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/**
 * @name: S7.4_A4_T3;
 * @section: 7.4;
 * @assertion: Single and Multi line comments are used together;  
 * @description: Insert Single line comment into Multi line comment;
*/

/*CHECK#1*/

/* var
//x
*/
