// Copyright 2009 the Sputnik authors.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/**
 * @name: S7.8.3_A4.1_T6;
 * @section: 7.8.3;
 * @assertion: DecimalLiteral :: ExponentPart is incorrect;  
 * @description: ExponentPart :: E DecimalDigits;
 * @negative
*/

//CHECK#1
E+1
