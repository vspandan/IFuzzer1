This dirctory is an archive of tests that have been removed from the test suite.
Many are tests of features that were removed from or changed in the final version of the ES5.  Some are just  bogus.
