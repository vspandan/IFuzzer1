
Running the tests
-----------------
If this folder contains a file named runtests.html open it with the browser you want to test.
Otherwise, go to to folder TestHarness
at the cmd prompt run build.bat
Your tests should run in the browser.
Thats it.

Inspecting the results
----------------------
The test results are reported in the browser (Look for the testName that you gave for your test).
Thats it.

