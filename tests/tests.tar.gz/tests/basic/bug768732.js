a = ''
b = []
a = b.concat(a)
Object.defineProperty(a, 3, {
  e: gczeal(4, 2)
})
