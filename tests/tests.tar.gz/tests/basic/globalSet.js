for (var i = 0; i < 500; i++)
  globalInt = i;

assertEq(globalInt, 499);
