// |jit-test| error: TypeError
{
    const x = 0;
    function x() { }
}
