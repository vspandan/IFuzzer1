for (var [...y] in Object) {} // dont assert
