// |jit-test|
(function (stdlib, heap) {
    "use asm";
    function f(i0) {
        i0 = i0 | 0;
        switch (0xc << (0xa % 1)) {
            case -2:
        };
    }
})()
