this.__defineSetter__("x", function(){});
this.watch("x", eval);
x = 0;
