// Don't assert.
try {
    var r = evalcx("new RegExp(\"\",\"\")", w);
    var s = "";
    (s.search(r))(x)
} catch (e) {}
    r = /()()()()/;
try {
    for (let x = 0; x < 3; ++x) {
        gc()
    }
} catch (e) {}
var w
