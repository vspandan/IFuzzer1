a = evalcx('');
for (var i = 0; i < 1000; i++) {
  a[i] = i;
}
function foo(x) {
  for (var i in x) 
        var summary = "Basic support for iterable objects and for-in";
}
schedulegc(1234);
foo(a);
