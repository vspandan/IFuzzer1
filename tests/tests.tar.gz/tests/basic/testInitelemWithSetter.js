Object.prototype.__defineSetter__(1, function () { throw "fit"; });
for (var i =0; i<9; i++)
    ({1:'a'});
