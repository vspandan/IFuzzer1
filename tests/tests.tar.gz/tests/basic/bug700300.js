for (let j = 0; j < (20); ++(__lookupSetter__)) {
  function g() { j; }
  j++;
}
