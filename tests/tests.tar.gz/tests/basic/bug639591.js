gczeal(2);
var x;
[eval("x")] ? eval("x") : 3;
eval("Object()");
