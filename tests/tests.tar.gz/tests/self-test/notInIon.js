// |jit-test| --no-ion

assertEq(inIon(), "Ion is disabled.");
