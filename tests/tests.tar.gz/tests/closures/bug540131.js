try {
 (function() {
   let(x = (eval("for(y in[0,0,0,0]){}"))) {}
 })()
} catch(e) {}
