Array.prototype.__proto__ = null;
for (var r = 0; r < 3; ++r) [][0] = 1;

// Don't crash.

