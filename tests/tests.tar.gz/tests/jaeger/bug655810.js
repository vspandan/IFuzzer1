function f(arr) {
    var x = arr[0];
    if (typeof x) {};
    Math.abs(x);
}
f([1.2]);
