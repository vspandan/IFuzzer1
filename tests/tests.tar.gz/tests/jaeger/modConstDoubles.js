
function f() {
    var x = 2.6;
    var y = 2.1;
    return x % y;
}
assertEq(f(), 0.5);

