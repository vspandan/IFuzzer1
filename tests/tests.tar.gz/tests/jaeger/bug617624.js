
function f() {
    var x;
    var a = x;
    Boolean(a = Number(12.34));
}
f();
