var arr = ['this', 'works', 'for', 'me'];
assertEq('this', arr[0]);
assertEq('works', arr[1]);
assertEq('for', arr[2]);
assertEq('me', arr[3]);

/* Multiple int32_t getelem for dense array. */
