if (typeof TypedObject === "undefined")
  quit();

(function() {
    Object
})()
var {
    Object
} = TypedObject
function f() {
    Object(Symbol)
}
for (var i = 0; i < 1; i++) {
    f()
}
