(function(stdlib) {
    "use asm";
    var pow = stdlib.Math.pow
    function f() {
        return +pow(.0, .0)
    }
    return f
})(this, {}, ArrayBuffer)()
