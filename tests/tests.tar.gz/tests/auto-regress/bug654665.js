// Binary: cache/js-dbg-64-3062ff7fef83-linux
// Flags: -m -n -a
//
test();
function test()
{
  for (var i = 0; i < 0e2.length; );
}
