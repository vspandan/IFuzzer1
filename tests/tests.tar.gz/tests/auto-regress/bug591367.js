// Binary: cache/js-dbg-32-33b05dd43cd4-linux
// Flags: -m
//
for (let x in []) {
  t(x !== x)
}
