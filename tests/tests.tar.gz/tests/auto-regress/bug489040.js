// Binary: cache/js-dbg-32-c319b49e2880-linux
// Flags: -j
//
for (var y = 0; y < 2; ++y) { (/x/)[this] }
