// |jit-test| error:ReferenceError

// Binary: cache/js-dbg-32-cc1e08803869-linux
// Flags:
//
(function(){clear()})()
