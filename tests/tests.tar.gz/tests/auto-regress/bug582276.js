// Binary: cache/js-dbg-32-e0988eae6c08-linux
// Flags: -m
//
(function() {
  this / z
  var z = ""
})()
