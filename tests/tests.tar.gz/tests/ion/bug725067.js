var o0 = [];
var o4 = {};
var o5 = Math;
function f6(o) { o[("Keywords")] = o;};
for(var i=0; i<20; i++) {
    f6(o0);
    f6(o4);
    f6(o5);
    print(i);
}
gc();
