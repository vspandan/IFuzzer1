var SECTION = "15.5.4.10-1";
function testInt8Array(L) {
    var f = new Int8Array(8);
}
for (var i = 0; i < 13000; ++i) {
    testInt8Array(SECTION,this);
}
