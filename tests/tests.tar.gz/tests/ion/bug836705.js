
Object.prototype[3] = 3;
var sjcl = {
    cipher: {},
};
sjcl.cipher.aes = function (a) {
    d = a.slice(0);
    for (a=0; a < 60; a++) {
        c = d[a - 1];
    }
};
new sjcl.cipher.aes([0xffffffff, 0xffffffff]);
