var x = 2;
outer:
while (x == 10) {
  while (x == 10) {
    if (x < (null ))
      continue outer;
    while (x < 10) {
      ((function() {}).abstract) = 0;
    }
  }
}
