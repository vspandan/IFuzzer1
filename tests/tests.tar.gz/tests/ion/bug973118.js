function h(x) { return +x == x };
h(false)
assertEq(h(null), false);
assertEq(h(null), false);
