int main ()
{
  *((char *)0) = 'a';
  return 0;
}