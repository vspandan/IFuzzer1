"product_divides.py" is good for playing with Lithium's "delta".

"sum_mod.py" is good for playing with Lithium's "remove-pair" and "remove-substring".