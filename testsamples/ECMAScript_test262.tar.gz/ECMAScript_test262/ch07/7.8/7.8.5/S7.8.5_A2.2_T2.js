// Copyright 2009 the Sputnik authors.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/**
 * RegularExpressionChar :: \ or / is incorrect
 *
 * @path ch07/7.8/7.8.5/S7.8.5_A2.2_T2.js
 * @description /
 * @negative
 */

//CHECK#1
/a//.source;

