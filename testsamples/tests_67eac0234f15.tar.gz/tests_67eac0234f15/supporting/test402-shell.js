/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/*
 * Test402 tests all pass unless they throw, and there are no @negative tests.
 * Once Test262 includes @negative support, and this call in test262-shell.js is
 * removed, this'll need to be uncommented.
 */
//testPassesUnlessItThrows();
