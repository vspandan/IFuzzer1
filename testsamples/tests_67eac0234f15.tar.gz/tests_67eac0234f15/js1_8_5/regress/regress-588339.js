({})
eval("{}")

/* Watch for crash. */
reportCompare(0, 0, "");
