// |reftest| slow
/*
 * Any copyright is dedicated to the Public Domain.
 * http://creativecommons.org/licenses/publicdomain/
 */
runDSTOffsetCachingTestsFraction(1, 8);
