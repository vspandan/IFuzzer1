// |reftest| slow
/*
 * Any copyright is dedicated to the Public Domain.
 * http://creativecommons.org/licenses/publicdomain/
 */
runDSTOffsetCachingTestsFraction(3, 8);
