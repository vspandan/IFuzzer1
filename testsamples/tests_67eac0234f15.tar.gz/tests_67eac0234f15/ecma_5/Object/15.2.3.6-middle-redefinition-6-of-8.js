// |reftest| skip-if(!xulRuntime.shell) -- uses shell load() function
// Any copyright is dedicated to the Public Domain.
// http://creativecommons.org/licenses/publicdomain/

load("ecma_5/Object/defineProperty-setup.js");
runNonTerminalPropertyPresentTestsFraction(6, 8);
