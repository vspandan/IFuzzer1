verifypostbarriers()
verifyprebarriers()
verifypostbarriers()
