if (typeof Symbol === "function") {
    gczeal(4);
    var symbols = [Symbol(), Symbol("comet"), Symbol.for("moon"), Symbol.iterator, 0];
    for (var a of symbols) {}
}
