function f0(p0) {
    var v0;
    var v1 = 0;
    var v2 = (v0 ^ v0) + v0;
    if (p0 | 0)
        v1 = v0;
    do break; while (v0);
    p0 ^ v1;
}
print(f0(1));

