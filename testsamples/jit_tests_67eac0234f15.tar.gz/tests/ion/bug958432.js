function h(i, i) {
    i = ([Infinity([])])(1 ? l : arguments)
}
for (var j = 0; j < 2; ++j) {
    try {
        h(-Number, -Number)
    } catch (e) {}
}

function f() {
    function f(i0, i1) {
        i0 = i0 | 0;
        i = i1 | 0;
        switch (1) {
            case -3:
                switch (f) {}
        } {
            return 0
        }(arguments)
    }
    return f
};
for (var j = 0; j < 5; ++j) {
    (function(x) {
        f()(f()(x, f()()))
    })()
}
