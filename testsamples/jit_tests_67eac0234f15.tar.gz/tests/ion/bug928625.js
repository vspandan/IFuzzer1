var summary = true;
evaluate("var summary = 'Array slice when arrays length is assigned';");
evaluate('var summary;');
