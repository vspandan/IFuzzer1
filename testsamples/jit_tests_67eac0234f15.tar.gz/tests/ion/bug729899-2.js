function f2() {
    __proto__ = null;
}

for (var j = 0; j < 50; j++)
    f2();
