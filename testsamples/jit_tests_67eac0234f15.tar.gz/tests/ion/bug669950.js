(function () {
    var x = true ? 1 : 2;
})();
