// Binary: cache/js-dbg-64-f5e128da7b5f-linux
// Flags:
//
x = Proxy.createFunction((function () {}), Uint16Array, wrap)
try { new(wrap(x)) } catch(exc1) {}
