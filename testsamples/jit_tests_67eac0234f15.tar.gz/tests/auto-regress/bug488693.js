// Binary: cache/js-dbg-32-ec03b7905b5a-linux
// Flags: -j
//
(new Function("for (var x = 0; x < 2; ++x) { gczeal(2)} "))()
