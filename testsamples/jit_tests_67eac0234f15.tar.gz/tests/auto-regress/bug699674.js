// Binary: cache/js-dbg-32-6dc7901db1d6-linux
// Flags:
//
Array(24)
for(v in(Array(2440598491))){}
