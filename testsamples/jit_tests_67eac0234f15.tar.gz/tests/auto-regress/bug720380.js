// Binary: cache/js-dbg-64-42368fe44c8c-linux
// Flags: -m -n
//

function MyObject( value ) {
  this.toBoolean = (this[ this.Function = this ]++ );
}
new MyObject(true);
