// Binary: cache/js-dbg-32-1fe03044bfeb-linux
// Flags: -m -n -a
//
try {
    function x() {}
} catch(e) {}
switch (undefined) {
    case(y) = Infinity:
}
