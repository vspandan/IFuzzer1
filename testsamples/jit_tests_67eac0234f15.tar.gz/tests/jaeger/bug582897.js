let(x) {
    x + x--
}

/* Don't assert. */

