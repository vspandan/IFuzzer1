
function stringConvert() {
  var a = Uint32Array.prototype;
  for (var i = 0; i < 10; i++) {
    a[0] = i;
  }
}
stringConvert();
