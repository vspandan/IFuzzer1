o0 = {};
g = new ArrayBuffer;
g2 = this;
v = g2.o0.t;
o0 = Object;
var y = {
  x: gc(gcPreserveCode())
}
y.toString();
for (z = 0; z < 100; z++) {}
