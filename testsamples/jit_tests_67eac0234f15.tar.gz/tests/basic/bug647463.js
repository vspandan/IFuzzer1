
try {
    eval("\
        [0].sort()\
    ")
} catch (e) {}
