try { (function() {
  new function() {
    throw [];
  }
})() } catch (e) {}
