
function throwsRangeError(t) {
    try {
        var date = arguments;
        date.setTime
    } catch (err) {
    }
}
throwsRangeError();
