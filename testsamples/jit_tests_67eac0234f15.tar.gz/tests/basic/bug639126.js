Array.__proto__ = Array.__proto__;
gc();
Array["name" + ""];
Array();
