Function("with([]){const x=0}")()
