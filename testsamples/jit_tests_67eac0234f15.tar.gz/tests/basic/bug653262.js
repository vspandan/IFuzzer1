with(evalcx(''))(function eval() {}, this.__defineGetter__("x", Function));
var i = 0;
var o;
new(x);
