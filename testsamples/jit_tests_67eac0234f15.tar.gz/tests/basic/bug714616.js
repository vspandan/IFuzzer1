array1 = new Array();
size   = 10;
for (i = 0; i < size; (array1.length)++)
{
  array1.push(array1.shift());
  ++i
}

