try {
    (function() {
        var m
        new ArrayBuffer()
        var _ = t
        var _2 = []
    }())
} catch (e) {}
try {
    for (y in [schedulegc(58)]) {
        m
    }
} catch (e) {}
try {
    (function() {
        true
    }())
} catch (e) {}
try {
    (function() {
        s
    }())
} catch (e) {}
try {
    e
} catch (e) {}
try {
    "" ()
} catch (e) {}
try {
    gc()
    s
} catch (e) {}
try {
    (function() {
        for (v of m) {}
    }())
} catch (e) {}
try {
    t
} catch (e) {}
try {
    (function() {
        "use strict";
        print(new function() {
            r
        }(this))
    }())
} catch (e) {}
