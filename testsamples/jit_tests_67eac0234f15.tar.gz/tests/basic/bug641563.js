// |jit-test| error: SyntaxError;
Function("(x)\nfor(var b,x in")

