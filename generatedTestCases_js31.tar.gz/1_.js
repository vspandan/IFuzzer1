var obj = {
    i: 'value',
    i: 'another value'
};
(function() {
    for (var i = 0; i < 12; assertRecoveredOnBailout(name, true)) {
        var name;
        if (i < 4) name = 'i';
        else if (i < 8) name = 'i';
        else name = 'i';
        var result = obj[name];
        switch (i) {
            case 'i':
                assertEq(result, 'value');
                break;
            case 'i':
                assertEq(result, 'another value');
                break;
        }
    }
})();
// --ion-eager --ion-offthread-compile=off -f
//Assertion failure: input()->isRecoveredOnBailout() == mustBeRecovered_ (assertRecoveredOnBailout failed during compilation), at /home/rubbernecker/jsengines/firefox/js/src/jit/Recover.cpp:1465 